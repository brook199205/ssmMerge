create view ejd as
  select `e`.`employee_id`     AS `employee_id`,
         `e`.`job_id`          AS `job_id`,
         `e`.`first_name`      AS `first_name`,
         `e`.`last_name`       AS `last_name`,
         `e`.`email`           AS `email`,
         `e`.`phone_number`    AS `phone_number`,
         `e`.`salary`          AS `salary`,
         `e`.`commission_pct`  AS `commission_pct`,
         `e`.`manager_id`      AS `manager_id`,
         `e`.`department_id`   AS `department_id`,
         `e`.`hiredate`        AS `hiredate`,
         `j`.`job_title`       AS `job_title`,
         `d`.`department_name` AS `department_name`
  from ((`myemployees`.`employees` `e` join `myemployees`.`jobs` `j` on ((`e`.`job_id` =
                                                                          `j`.`job_id`))) join `myemployees`.`departments` `d` on ((
    `e`.`department_id` = `d`.`department_id`)));

